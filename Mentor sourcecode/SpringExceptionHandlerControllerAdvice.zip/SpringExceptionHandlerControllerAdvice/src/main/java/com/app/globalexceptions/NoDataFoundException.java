package com.app.globalexceptions;

public class NoDataFoundException extends RuntimeException {

	public NoDataFoundException(String message) {
		super(message);
	}
}
