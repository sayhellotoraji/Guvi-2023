package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.app.globalexceptions.NoDataFoundException;
import com.app.globalexceptions.ResourceNotFoundException;
import com.app.model.Employee;

@Service
public class EmployeeService {

	public List<Employee>empdata(){
		
	Employee obj= new Employee();
	obj.setId(1);
	obj.setName("Arjun");
	obj.setAge(20);
	obj.setLocation("chennai");
	
	Employee obj1= new Employee();
	obj1.setId(2);
	obj1.setName("Wikki");
	obj1.setAge(30);
	obj1.setLocation("madurai");
	
	Employee obj2= new Employee();
	obj2.setId(3);
	obj2.setName("Thirumal");
	obj2.setAge(40);
	obj2.setLocation("tuticorin");

	List<Employee>list= new ArrayList<>();
	list.add(obj);
	list.add(obj1);
	list.add(obj2);
	
	return list;
		
	}
	
	public List<Employee> getempdetails() {
		List<Employee>list1= empdata();
		if (list1.size()>0) {
			return list1;
		}
		throw new NoDataFoundException("No employees available");

	}
	
	public Employee getEmployeedata (Integer id) {
		List<Employee>list2= empdata();
		Optional<Employee> theEmployee = list2.stream().filter(e -> e.getId() == id).findFirst();
		if (!theEmployee.isPresent()) {
			throw new ResourceNotFoundException("Employee not found for the id->"+id);
		}
		return theEmployee.get();
	}
}
